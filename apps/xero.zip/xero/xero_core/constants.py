"""
Constants for xero_core app.
"""

# Constants will be added here

