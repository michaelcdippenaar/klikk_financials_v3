"""
Custom exceptions for xero_core app.
"""


class XeroCoreException(Exception):
    """Base exception for xero_core app."""
    pass

# Add custom exceptions here

