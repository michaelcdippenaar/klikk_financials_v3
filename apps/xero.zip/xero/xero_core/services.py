"""
Core Xero API client services.
"""
import datetime
import logging
import requests
from django.utils import timezone
from xero_python.accounting import AccountingApi
from xero_python.api_client import ApiClient, Configuration
from xero_python.api_client.oauth2 import OAuth2Token
from xero_python.api_client.serializer import serialize

from apps.xero.xero_core.models import XeroTenant
from apps.xero.xero_auth.models import XeroClientCredentials, XeroTenantToken, XeroAuthSettings

logger = logging.getLogger(__name__)

# Cache for XeroAuthSettings to avoid repeated database queries
_auth_settings_cache = None


def serialize_model(model):
    """
    Serialize a Xero API response object into a Python dictionary.

    Args:
        model: Xero API response object (e.g., Accounts, Journals).

    Returns:
        dict: Serialized data as a Python dictionary.
    """
    try:
        serialized = serialize(model)
        logger.debug(f"Serialized model: {type(model)} to dict")
        return serialized
    except Exception as e:
        logger.error(f"Failed to serialize model {type(model)}: {str(e)}")
        raise


class XeroApiClient:
    def __init__(self, user, tenant_id=None):
        self.user = user
        self.tenant_id = tenant_id
        self.credentials = XeroClientCredentials.objects.get(user=self.user, active=True)
        self.api_client = ApiClient(
            Configuration(
                debug=False,
                oauth2_token=OAuth2Token(
                    client_id=self.credentials.client_id,
                    client_secret=self.credentials.client_secret
                )
            ),
            pool_threads=1,
        )
        self.tenant_token = None
        if tenant_id:
            self.tenant_token = self.get_tenant_token()
            self.configure_api_client(self.tenant_token)

    def get_tenant_token(self):
        try:
            credentials = XeroClientCredentials.objects.get(user=self.user, active=True)
        except XeroClientCredentials.DoesNotExist:
            raise ValueError(f"No active credentials found for user {self.user.username}")
        
        try:
            tenant_token = XeroTenantToken.objects.get(tenant__tenant_id=self.tenant_id, credentials=credentials)
        except XeroTenantToken.DoesNotExist:
            raise ValueError(
                f"No token found for tenant {self.tenant_id}. "
                f"Please re-authenticate this tenant through the Xero authorization flow."
            )
        
        # Check if refresh token exists
        if not tenant_token.refresh_token:
            raise ValueError(
                f"No refresh token available for tenant {self.tenant_id}. "
                f"Please re-authenticate this tenant through the Xero authorization flow."
            )
        
        # Refresh token if expired during initialization
        try:
            self.refresh_token_if_expired(tenant_token)
        except ValueError as e:
            # Re-raise with context
            raise
        except Exception as e:
            raise ValueError(
                f"Failed to refresh token for tenant {self.tenant_id}: {str(e)}. "
                f"Please re-authenticate this tenant."
            ) from e
        
        # Reload from database to get updated token if it was refreshed
        tenant_token.refresh_from_db()
        return tenant_token

    def configure_api_client(self, tenant_token):
        # Store reference to self for use in closures
        api_client_instance = self
        
        @self.api_client.oauth2_token_getter
        def obtain_xero_oauth2_token():
            if not api_client_instance.tenant_token:
                raise ValueError("Tenant token not configured. Initialize XeroApiClient with tenant_id.")
            
            # Check if this is a temporary token (not saved to DB) - used during OAuth callback
            # Temporary tokens have tenant_id='temp' or don't have a primary key
            is_temp_token = (
                not hasattr(api_client_instance.tenant_token, 'pk') or 
                api_client_instance.tenant_token.pk is None or
                (hasattr(api_client_instance.tenant_token, 'tenant') and 
                 api_client_instance.tenant_token.tenant.tenant_id == 'temp')
            )
            
            if is_temp_token:
                # For temporary tokens, just return the token directly without DB operations
                return api_client_instance.tenant_token.token
            
            # For saved tokens, check expiration and refresh if needed
            current_time = timezone.now()
            expires_at = api_client_instance.tenant_token.expires_at
            
            # Only reload from DB and refresh if token is expired or expiring soon
            if expires_at and expires_at <= current_time + datetime.timedelta(seconds=30):
                try:
                    api_client_instance.tenant_token.refresh_from_db()
                    # Check again after reload (in case it was refreshed by another process)
                    if api_client_instance.tenant_token.expires_at <= current_time + datetime.timedelta(seconds=30):
                        api_client_instance.refresh_token_if_expired(api_client_instance.tenant_token)
                        # Reload after refresh to get updated token
                        api_client_instance.tenant_token.refresh_from_db()
                except Exception as e:
                    # If refresh_from_db fails (e.g., token was deleted), log and continue with in-memory token
                    logger.warning(f"Could not refresh token from DB: {str(e)}, using in-memory token")
            
            return api_client_instance.tenant_token.token

        @self.api_client.oauth2_token_saver
        def store_xero_oauth2_token(token):
            tenant_token.token = token
            tenant_token.refresh_token = token.get('refresh_token')
            tenant_token.expires_at = timezone.now() + datetime.timedelta(seconds=token.get('expires_in'))
            tenant_token.save()

    def refresh_token_if_expired(self, tenant_token):
        """Check if token is expired and refresh it if needed."""
        # Add a small buffer (30 seconds) to refresh before actual expiration
        if tenant_token.expires_at and tenant_token.expires_at <= timezone.now() + datetime.timedelta(seconds=30):
            logger.info(f"Token expired or expiring soon (expires_at: {tenant_token.expires_at}), refreshing...")
            # Use cached auth settings to avoid repeated database queries
            global _auth_settings_cache
            if _auth_settings_cache is None:
                _auth_settings_cache = XeroAuthSettings.objects.first()
            auth_settings = _auth_settings_cache
            
            if not auth_settings:
                raise ValueError("XeroAuthSettings not configured in the database")
            credentials = tenant_token.credentials
            refresh_url = auth_settings.refresh_url
            headers = {
                "Content-Type": "application/x-www-form-urlencoded"
            }
            data = {
                "grant_type": "refresh_token",
                "client_id": credentials.client_id,
                "client_secret": credentials.client_secret,
                "refresh_token": tenant_token.refresh_token
            }
            try:
                response = requests.post(refresh_url, headers=headers, data=data, timeout=30)
                response.raise_for_status()
                new_token = response.json()
                # Update the specific tenant token
                tenant_token.token = new_token
                tenant_token.refresh_token = new_token.get('refresh_token', tenant_token.refresh_token)
                tenant_token.expires_at = timezone.now() + datetime.timedelta(seconds=new_token.get('expires_in', 1800))
                tenant_token.save()
                logger.info(f"Successfully refreshed token for tenant {tenant_token.tenant.tenant_id}")
            except requests.HTTPError as e:
                # Log detailed error information
                error_details = {
                    'status_code': e.response.status_code if e.response else None,
                    'url': refresh_url,
                    'tenant_id': tenant_token.tenant.tenant_id,
                    'error': str(e)
                }
                try:
                    if e.response:
                        error_details['response_body'] = e.response.text[:500]  # Limit response body length
                        error_details['response_json'] = e.response.json() if e.response.headers.get('content-type', '').startswith('application/json') else None
                except:
                    pass  # Ignore errors parsing response
                
                logger.error(
                    f"Failed to refresh token for tenant {tenant_token.tenant.tenant_id}: "
                    f"HTTP {error_details['status_code']} - {error_details.get('response_body', str(e))}",
                    extra=error_details
                )
                
                # Raise a more descriptive error
                error_msg = f"Token refresh failed for tenant {tenant_token.tenant.tenant_id}"
                if error_details.get('response_json') and 'error' in error_details['response_json']:
                    error_msg += f": {error_details['response_json']['error']}"
                    if 'error_description' in error_details['response_json']:
                        error_msg += f" - {error_details['response_json']['error_description']}"
                else:
                    error_msg += f" (HTTP {error_details['status_code']})"
                
                raise ValueError(error_msg) from e
            except requests.RequestException as e:
                logger.error(
                    f"Failed to refresh token for tenant {tenant_token.tenant.tenant_id}: {str(e)}",
                    exc_info=True
                )
                raise ValueError(f"Token refresh request failed for tenant {tenant_token.tenant.tenant_id}: {str(e)}") from e


class XeroAccountingApi:
    def __init__(self, api_client, tenant_id):
        from apps.xero.xero_metadata.models import XeroAccount, XeroTracking, XeroContacts
        from apps.xero.xero_data.models import XeroTransactionSource, XeroJournalsSource
        from apps.xero.xero_sync.models import XeroLastUpdate
        
        self.tenant_id = tenant_id
        self.api_client = AccountingApi(api_client.api_client)
        self.organisation = XeroTenant.objects.get(tenant_id=tenant_id)

    def accounts(self):
        from apps.xero.xero_metadata.models import XeroAccount
        
        class Accounts:
            def __init__(self, parent):
                self.parent = parent
                self.api_client = parent.api_client
                self.organisation = parent.organisation

            def get(self):
                from apps.xero.xero_core.services import serialize_model
                accounts_obj = self.api_client.get_accounts(self.parent.tenant_id)
                response = serialize_model(accounts_obj)['Accounts']
                XeroAccount.objects.create_accounts(self.organisation, response)

        return Accounts(self)

    def tracking_categories(self):
        from apps.xero.xero_metadata.models import XeroTracking
        
        class TrackingCategories:
            def __init__(self, parent):
                self.parent = parent
                self.api_client = parent.api_client
                self.organisation = parent.organisation

            def get(self):
                from apps.xero.xero_core.services import serialize_model
                print('Updating Tracking Categories')
                tracking_obj = self.api_client.get_tracking_categories(self.parent.tenant_id, include_archived='True')
                response = serialize_model(tracking_obj)['TrackingCategories']
                print(response)
                XeroTracking.objects.create_tracking_categories_from_xero(self.organisation, response)

        return TrackingCategories(self)

    def contacts(self):
        from apps.xero.xero_metadata.models import XeroContacts
        
        class Contacts:
            def __init__(self, parent):
                self.parent = parent
                self.api_client = parent.api_client
                self.organisation = parent.organisation

            def get(self):
                from apps.xero.xero_core.services import serialize_model
                contacts_obj = self.api_client.get_contacts(self.parent.tenant_id)
                response = serialize_model(contacts_obj)['Contacts']
                XeroContacts.objects.create_contacts_from_xero(self.organisation, response)

        return Contacts(self)

    def bank_transactions(self):
        from apps.xero.xero_data.models import XeroTransactionSource
        
        class BankTransactions:
            def __init__(self, parent):
                self.parent = parent
                self.api_client = parent.api_client
                self.organisation = parent.organisation

            def get(self):
                from apps.xero.xero_core.services import serialize_model
                bank_trans_obj = self.api_client.get_bank_transactions(self.parent.tenant_id)
                response = serialize_model(bank_trans_obj)['BankTransactions']
                XeroTransactionSource.objects.create_bank_transaction_from_xero(self.organisation, response)

        return BankTransactions(self)

    def invoices(self):
        from apps.xero.xero_data.models import XeroTransactionSource
        
        class Invoices:
            def __init__(self, parent):
                self.parent = parent
                self.api_client = parent.api_client
                self.organisation = parent.organisation

            def get(self):
                from apps.xero.xero_core.services import serialize_model
                invoices_obj = self.api_client.get_invoices(self.parent.tenant_id)
                response = serialize_model(invoices_obj)['Invoices']
                XeroTransactionSource.objects.create_invoices_from_xero(self.organisation, response)

        return Invoices(self)

    def payments(self):
        from apps.xero.xero_data.models import XeroTransactionSource
        
        class Payments:
            def __init__(self, parent):
                self.parent = parent
                self.api_client = parent.api_client
                self.organisation = parent.organisation

            def get(self):
                from apps.xero.xero_core.services import serialize_model
                payments_obj = self.api_client.get_payments(self.parent.tenant_id)
                response = serialize_model(payments_obj)['Payments']
                XeroTransactionSource.objects.create_payments_from_xero(self.organisation, response)

        return Payments(self)

    def journals(self, load_all=False):
        """
        Get regular journals (non-manual) from Xero API.
        
        Args:
            load_all: If True, ignore last update timestamp and load all journals. Default False.
        """
        return self._get_journals_base('journal', 'journals', load_all=load_all)
    
    def manual_journals(self, load_all=False):
        """
        Get manual journals from Xero API.
        
        Args:
            load_all: If True, ignore last update timestamp and load all journals. Default False.
        """
        return self._get_journals_base('manual_journal', 'manual_journals', load_all=load_all)
    
    def load_journals(self, load_all=True, load_manual_journals=True, load_journals=True):
        """
        Unified method to load journals based on parameters.
        
        Args:
            load_all: If True (default), ignore last update timestamp and load everything for selected journal types.
                      If False, use incremental updates based on last update timestamp.
                      Note: This controls timestamp behavior, not which types to load.
            load_manual_journals: If True (default), load manual journals.
            load_journals: If True (default), load regular journals.
        
        Returns:
            dict: Results with success status and any errors
        """
        results = {
            'success': True,
            'errors': [],
            'loaded_types': []
        }
        
        # Respect individual flags for which journal types to load
        # load_all only controls whether to ignore timestamps
        print(f"[LOAD_JOURNALS] Parameters: load_all={load_all}, load_journals={load_journals}, load_manual_journals={load_manual_journals}")
        
        if load_journals:
            print(f"[LOAD_JOURNALS] Loading regular journals (load_all={load_all})")
            try:
                self.journals(load_all=load_all).get()
                results['loaded_types'].append('journals')
            except Exception as e:
                results['success'] = False
                results['errors'].append(f"Failed to load journals: {str(e)}")
        else:
            print(f"[LOAD_JOURNALS] Skipping regular journals (load_journals=False)")
        
        if load_manual_journals:
            print(f"[LOAD_JOURNALS] Loading manual journals (load_all={load_all})")
            try:
                self.manual_journals(load_all=load_all).get()
                results['loaded_types'].append('manual_journals')
            except Exception as e:
                results['success'] = False
                results['errors'].append(f"Failed to load manual journals: {str(e)}")
        else:
            print(f"[LOAD_JOURNALS] Skipping manual journals (load_manual_journals=False)")
        
        return results
    
    def _get_journals_base(self, journal_type, last_update_key, load_all=False):
        """
        Base class for fetching journals (both regular and manual).
        
        Args:
            journal_type: 'journal' or 'manual_journal'
            last_update_key: Key for XeroLastUpdate (e.g., 'journals' or 'manual_journals')
            load_all: If True, ignore last update timestamp and load all journals. Default False.
        """
        from apps.xero.xero_data.models import XeroJournalsSource
        from apps.xero.xero_sync.models import XeroLastUpdate
        
        class BaseJournals:
            def __init__(self, parent, journal_type, last_update_key, load_all):
                self.parent = parent
                self.api_client = parent.api_client
                self.organisation = parent.organisation
                self.journal_type = journal_type
                self.last_update_key = last_update_key
                self.load_all = load_all

            def get(self):
                from apps.xero.xero_core.services import serialize_model
                
                try:
                    journals_to_process = []
                    journal_ids_to_fetch = []
                    
                    # Determine which API method to call based on journal type
                    if self.journal_type == 'manual_journal':
                        api_method = self.api_client.get_manual_journals
                        serializer_key = 'ManualJournals'
                        print_prefix = "[MANUAL_JOURNALS]"
                        # Manual journals don't support offset pagination - fetch all at once
                        use_offset_pagination = False
                        # Manual journals use 'ManualJournalID' instead of 'JournalID'
                        journal_id_key = 'ManualJournalID'
                    else:
                        api_method = self.api_client.get_journals
                        serializer_key = 'Journals'
                        print_prefix = "[JOURNALS]"
                        # Regular journals support offset pagination
                        use_offset_pagination = True
                        # Regular journals use 'JournalID'
                        journal_id_key = 'JournalID'
                    
                    # If load_all is True, ignore last update timestamp (set to None)
                    # Otherwise, use incremental updates based on last update time
                    if self.load_all:
                        modified_since = None
                        print(f"{print_prefix} Loading ALL {self.journal_type} (ignoring last update timestamp)")
                    else:
                        modified_since = XeroLastUpdate.objects.get_utc_date_time(self.last_update_key, self.organisation)
                        print(f"{print_prefix} Loading {self.journal_type} modified since {modified_since}")
                    
                    if use_offset_pagination:
                        # Collect all journals using numeric offset pagination (0, 100, 200, etc.)
                        offset = 0
                        page_size = 100
                        while True:
                            print(f"{print_prefix} Fetching {self.journal_type} with offset={offset}, limit={page_size}")
                            # Only pass if_modified_since if it's not None (incremental update)
                            if modified_since:
                                journals_obj = api_method(
                                    self.parent.tenant_id, offset=offset, if_modified_since=modified_since
                                )
                            else:
                                journals_obj = api_method(
                                    self.parent.tenant_id, offset=offset
                                )
                            journal_set = serialize_model(journals_obj)[serializer_key]
                            if not journal_set:
                                print(f"{print_prefix} No more {self.journal_type} found. Final offset={offset}")
                                break
                            
                            print(f"{print_prefix} Retrieved {len(journal_set)} {self.journal_type} at offset={offset}")
                            
                            # If we got fewer than page_size, this is the last page
                            if len(journal_set) < page_size:
                                print(f"{print_prefix} Last page reached. Final offset={offset}")
                            
                            for journal in journal_set:
                                journal_id = journal.get(journal_id_key) or journal.get('JournalID') or journal.get('ManualJournalID')
                                if not journal_id:
                                    logger.warning(f"Skipping journal: No ID found. Available keys: {list(journal.keys())}")
                                    continue
                                journal_ids_to_fetch.append(journal_id)
                                journals_to_process.append({
                                    'journal_id': journal_id,
                                    'journal_number': journal.get('JournalNumber', journal.get('ManualJournalNumber', 0)),
                                    'collection': journal,
                                })
                            
                            # Increment offset by page_size for next iteration
                            offset += page_size
                            
                            # If we got fewer than page_size, we've reached the end
                            if len(journal_set) < page_size:
                                break
                        
                        print(f"{print_prefix} Completed fetching all {self.journal_type}. Total: {len(journals_to_process)}, Final offset: {offset}")
                    else:
                        # Manual journals - fetch all at once (no pagination support)
                        print(f"{print_prefix} Fetching all {self.journal_type} (no pagination)")
                        # Only pass if_modified_since if it's not None (incremental update)
                        if modified_since:
                            journals_obj = api_method(
                                self.parent.tenant_id, if_modified_since=modified_since
                            )
                        else:
                            journals_obj = api_method(
                                self.parent.tenant_id
                            )
                        journal_set = serialize_model(journals_obj)[serializer_key]
                        
                        if journal_set:
                            print(f"{print_prefix} Retrieved {len(journal_set)} {self.journal_type}")
                            # Debug: Print first journal structure if available
                            if journal_set and len(journal_set) > 0:
                                sample_keys = list(journal_set[0].keys())
                                print(f"{print_prefix} Sample journal keys: {sample_keys}")
                            
                            for journal in journal_set:
                                # Try multiple possible ID field names
                                journal_id = (
                                    journal.get(journal_id_key) or 
                                    journal.get('JournalID') or 
                                    journal.get('ManualJournalID') or
                                    journal.get('ID')
                                )
                                if not journal_id:
                                    logger.warning(f"Skipping journal: No ID found. Available keys: {list(journal.keys())}")
                                    print(f"{print_prefix} WARNING: Journal missing ID. Keys: {list(journal.keys())}")
                                    continue
                                
                                # Try multiple possible journal number field names
                                # Manual journals don't have JournalNumber, so generate one
                                if self.journal_type == 'manual_journal':
                                    # Generate journal number from ManualJournalID hash
                                    journal_number = abs(hash(journal_id)) % 1000000
                                else:
                                    journal_number = (
                                        journal.get('JournalNumber') or 
                                        journal.get('ManualJournalNumber') or
                                        journal.get('Number') or
                                        0
                                    )
                                
                                journal_ids_to_fetch.append(journal_id)
                                journals_to_process.append({
                                    'journal_id': journal_id,
                                    'journal_number': journal_number,
                                    'collection': journal,
                                })
                        else:
                            print(f"{print_prefix} No {self.journal_type} found")
                        
                        print(f"{print_prefix} Completed fetching all {self.journal_type}. Total: {len(journals_to_process)}")
                    
                    # Bulk update/create journals using bulk operations
                    if journals_to_process:
                        # Fetch existing journals in one query (filter by journal_type)
                        existing_journals = {
                            j.journal_id: j for j in XeroJournalsSource.objects.filter(
                                organisation=self.organisation,
                                journal_id__in=journal_ids_to_fetch,
                                journal_type=self.journal_type
                            )
                        }
                        
                        to_create = []
                        to_update = []
                        
                        for journal_data in journals_to_process:
                            journal_id = journal_data['journal_id']
                            if journal_id in existing_journals:
                                # Update existing
                                existing = existing_journals[journal_id]
                                existing.journal_number = journal_data['journal_number']
                                existing.collection = journal_data['collection']
                                existing.journal_type = self.journal_type  # Update journal type
                                existing.processed = False
                                to_update.append(existing)
                            else:
                                # Create new
                                to_create.append(XeroJournalsSource(
                                    organisation=self.organisation,
                                    journal_id=journal_id,
                                    journal_number=journal_data['journal_number'],
                                    journal_type=self.journal_type,
                                    collection=journal_data['collection'],
                                    processed=False
                                ))
                        
                        # Bulk create and update
                        if to_create:
                            XeroJournalsSource.objects.bulk_create(to_create, ignore_conflicts=True)
                        if to_update:
                            XeroJournalsSource.objects.bulk_update(to_update, ['journal_number', 'journal_type', 'collection', 'processed'])
                    
                    XeroJournalsSource.objects.create_journals_from_xero(self.organisation)
                    
                    # Only update timestamp if not loading all (incremental update)
                    if not self.load_all:
                        XeroLastUpdate.objects.update_or_create_timestamp(self.last_update_key, self.organisation)
                        logger.info(f"Successfully updated {self.journal_type} and timestamp for tenant {self.organisation.tenant_id}")
                    else:
                        logger.info(f"Successfully loaded all {self.journal_type} for tenant {self.organisation.tenant_id} (timestamp not updated)")
                except Exception as e:
                    logger.error(f"Failed to update {self.journal_type} for tenant {self.organisation.tenant_id}: {str(e)}")
                    raise

        return BaseJournals(self, journal_type, last_update_key, load_all)

    def profit_and_loss(self):
        """
        Get Profit and Loss report from Xero API.
        """
        class ProfitAndLoss:
            def __init__(self, parent):
                self.parent = parent
                self.api_client = parent.api_client
                self.organisation = parent.organisation

            def get(self, from_date, to_date, periods=11, timeframe='MONTH'):
                """
                Get Profit and Loss report.
                
                Args:
                    from_date: Start date (YYYY-MM-DD format)
                    to_date: End date (YYYY-MM-DD format)
                    periods: Number of periods (default 11 for 12 months)
                    timeframe: MONTH, QUARTER, or YEAR
                
                Returns:
                    Serialized P&L report data
                """
                from apps.xero.xero_core.services import serialize_model
                pnl_obj = self.api_client.get_report_profit_and_loss(
                    self.parent.tenant_id,
                    from_date=from_date,
                    to_date=to_date,
                    periods=periods,
                    timeframe=timeframe
                )
                return serialize_model(pnl_obj)

        return ProfitAndLoss(self)
