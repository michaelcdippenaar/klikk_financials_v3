from django.apps import AppConfig


class XeroCoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.xero.xero_core'
    verbose_name = 'Xero Core'

