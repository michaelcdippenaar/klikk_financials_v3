"""
Xero cube services - data processing and consolidation.
"""
import datetime
import time
import logging
import pandas as pd
from django.db.models import Q, Sum, F

from apps.xero.xero_core.models import XeroTenant
from apps.xero.xero_data.models import XeroJournals, Month, Year
from apps.xero.xero_cube.models import XeroTrailBalance, XeroBalanceSheet

logger = logging.getLogger(__name__)


def process_journals(tenant_id):
    """Process journals from source."""
    print('[PROCESS JOURNALS] Start Processing Journals from XeroJournalsSource')
    logger.info(f'Start Processing Journals for tenant {tenant_id}')
    organisation = XeroTenant.objects.get(tenant_id=tenant_id)
    from apps.xero.xero_data.models import XeroJournalsSource
    result = XeroJournalsSource.objects.create_journals_from_xero(organisation)
    print(f'[PROCESS JOURNALS] Journals processing complete')
    logger.info(f'Journals processing complete for tenant {tenant_id}')


def create_trail_balance(tenant_id, incremental=False):
    """
    Create trail balance from journals.
    
    Args:
        tenant_id: Xero tenant ID
        incremental: If True, only process journals updated since last run
    """
    from apps.xero.xero_sync.models import XeroLastUpdate
    
    organisation = XeroTenant.objects.get(tenant_id=tenant_id)
    
    # Get last update date for incremental updates
    last_update_date = None
    if incremental:
        try:
            last_update = XeroLastUpdate.objects.get(
                end_point='journals',
                organisation=organisation
            )
            if last_update.date:
                last_update_date = last_update.date
                logger.info(f"Using incremental update from {last_update_date}")
                print(f"[TRAIL BALANCE] Using incremental update from {last_update_date}")
        except XeroLastUpdate.DoesNotExist:
            logger.info("No previous update found, doing full rebuild")
            print(f"[TRAIL BALANCE] No previous update found, doing full rebuild")
    
    # Get account balances - filter by date if incremental
    if last_update_date:
        # For incremental updates, we need to:
        # 1. First, get the affected periods (year/month) from new journals
        # 2. Then get ALL journals for those periods (not just new ones) to recalculate totals correctly
        logger.info(f"Incremental update mode: identifying affected periods since {last_update_date}")
        print(f"[TRAIL BALANCE] Incremental update mode: identifying affected periods since {last_update_date}")
        
        # Step 1: Get new journals to identify affected periods
        new_journals = XeroJournals.objects.filter(
            organisation=organisation,
            date__gte=last_update_date
        ).annotate(
            month=Month('date'),
            year=Year('date')
        ).values('year', 'month').distinct()
        
        affected_periods = list(new_journals)
        logger.info(f"Affected periods: {affected_periods}")
        print(f"[TRAIL BALANCE] Found {len(affected_periods)} affected periods: {affected_periods}")
        
        if affected_periods:
            # Step 2: Get ALL journals for affected periods (not just new ones)
            # This ensures we recalculate totals correctly
            period_filters = Q()
            for period in affected_periods:
                period_filters |= Q(
                    date__year=period['year'],
                    date__month=period['month']
                )
            
            # Get all journals for affected periods
            qs = XeroJournals.objects.filter(
                organisation=organisation
            ).filter(period_filters).annotate(
                month=Month('date')
            ).annotate(
                year=Year('date')
            ).annotate(
                contact=F('transaction_source__contact')
            ).values("account", "year", "month", "contact", "tracking1", "tracking2").order_by().annotate(
                amount=Sum("amount"),
            )
            logger.info(f"Incremental update: recalculating {len(affected_periods)} affected periods with all journals")
            print(f"[TRAIL BALANCE] Recalculating {len(affected_periods)} affected periods, found {qs.count()} journal aggregates")
        else:
            logger.warning("No affected periods found in incremental mode, but continuing with full rebuild")
            print(f"[TRAIL BALANCE] WARNING: No affected periods found, falling back to full rebuild")
            # Fall back to full rebuild if no affected periods
            qs = XeroJournals.objects.get_account_balances(organisation)
            last_update_date = None  # Clear last_update_date to trigger full rebuild in consolidate_journals
    else:
        # Get all balances for full rebuild
        logger.info("Full rebuild mode: getting all account balances")
        print(f"[TRAIL BALANCE] Full rebuild mode: getting all account balances")
        qs = XeroJournals.objects.get_account_balances(organisation)
        print(f"[TRAIL BALANCE] Found {qs.count()} journal aggregates for full rebuild")
    
    print(f'[TRAIL BALANCE] Start Consolidate Journal Process - {qs.count()} journal aggregates to process')
    logger.info(f"Consolidating {qs.count()} journal aggregates into trail balance")
    
    # Convert queryset to list to ensure we can iterate multiple times
    journals_list = list(qs)
    print(f'[TRAIL BALANCE] Converted to list: {len(journals_list)} items')
    
    result = XeroTrailBalance.objects.consolidate_journals(organisation, journals_list, last_update_date=last_update_date)
    print(f'[TRAIL BALANCE] Consolidation complete, checking created records...')
    
    tb = XeroTrailBalance.objects.filter(organisation=organisation).select_related(
        'account', 'account__business_unit', 'contact', 'tracking1', 'tracking2', 'organisation'
    )
    tb_count = tb.count()
    print(f'[TRAIL BALANCE] Total trail balance records after consolidation: {tb_count}')
    logger.info(f"Trail balance consolidation complete: {tb_count} total records")
    
    print('Start Trail Balance - Google Export')
    
    df = tb.to_dataframe([
        'organisation__tenant_id', 'organisation__tenant_name',
        'year', 'month', 'fin_year', 'fin_period',
        'account__account_id',
        'account__type',
        'account__grouping',
        'account__code',
        'account__name',
        'account__business_unit__business_unit_code',
        'account__business_unit__business_unit_description',
        'account__business_unit__division_code',
        'account__business_unit__division_description',
        'contact__name',
        'contact__contacts_id',
        'tracking1__option',
        'tracking2__option',
        'amount'
    ])

    print('Trail Balance - DataFrame Created')

    # Filter zero amounts and convert to numeric types for BigQuery
    df = df[df.amount != 0].copy()
    df['amount'] = pd.to_numeric(df['amount'], errors='coerce')
    df['fin_period'] = pd.to_numeric(df['fin_period'], errors='coerce')
    table_id = f'Xero.TrailBalance_Movement_V2_{tenant_id.replace("-", "_")}'
    
    # Export to BigQuery (via integration service)
    from apps.xero.xero_integration.services import update_google_big_query, run_async_export, update_google_big_query_async
    try:
        run_async_export(update_google_big_query_async(df, table_id))
    except Exception as e:
        # Fallback to sync version if async fails
        logger.warning(f"Async export failed, using sync: {str(e)}")
        update_google_big_query(df, table_id)
    print('End Trail Balance - Google Export')


def create_balance_sheet(tenant_id):
    """Create balance sheet from trail balance."""
    organisation = XeroTenant.objects.get(tenant_id=tenant_id)
    XeroBalanceSheet.objects.consolidate_balance_sheet(organisation)
    tb = XeroBalanceSheet.objects.filter(organisation=organisation).select_related(
        'account', 'account__business_unit', 'contact', 'organisation'
    )
    df = tb.to_dataframe([
        'organisation__tenant_id', 'organisation__tenant_name', 'year', 'month',
        'account__account_id', 'account__type', 'account__business_unit__division_code',
        'account__business_unit__division_description', 'account__business_unit__business_unit_code',
        'account__business_unit__business_unit_description', 'account__grouping', 'account__code',
        'account__name', 'contact__name', 'amount', 'balance'
    ])
    df['amount'] = pd.to_numeric(df['amount'])
    df['balance'] = pd.to_numeric(df['balance'])
    table_id = f'Xero.BalanceSheet_Balance_{tenant_id.replace("-", "_")}'
    
    # Export to BigQuery (via integration service)
    from apps.xero.xero_integration.services import update_google_big_query, run_async_export, update_google_big_query_async
    try:
        run_async_export(update_google_big_query_async(df, table_id))
    except Exception as e:
        # Fallback to sync version if async fails
        logger.warning(f"Async export failed, using sync: {str(e)}")
        update_google_big_query(df, table_id)


def process_xero_data(tenant_id):
    """
    Service function to process Xero data (trail balance, etc.).
    Extracted from XeroProcessDataView for use in scheduled tasks.
    
    Args:
        tenant_id: Xero tenant ID
    
    Returns:
        dict: Result with status, message, and stats
    """
    start_time = time.time()
    
    try:
        tenant = XeroTenant.objects.get(tenant_id=tenant_id)
    except XeroTenant.DoesNotExist:
        raise ValueError(f"Tenant {tenant_id} not found")
    
    stats = {
        'journals_processed': False,
        'trail_balance_created': False,
        'balance_sheet_created': False,
        'accounts_exported': False,
    }
    
    try:
        # Step 1: Process journals from XeroJournalsSource to XeroJournals
        logger.info(f'Start Processing Journals for tenant {tenant_id}')
        print(f"[PROCESS] Starting journal processing for tenant {tenant_id}")
        process_journals(tenant_id)
        stats['journals_processed'] = True
        print(f"[PROCESS] ✓ Journals processed")
        logger.info(f'Journals processed for tenant {tenant_id}')
        
        # Step 2: Create trail balance from processed journals
        logger.info(f'Start Creating Trail Balance for tenant {tenant_id}')
        print(f"[PROCESS] Starting trail balance creation for tenant {tenant_id}")
        create_trail_balance(tenant_id, incremental=True)  # Use incremental updates
        stats['trail_balance_created'] = True
        print(f"[PROCESS] ✓ Trail balance created")
        
        # Uncomment if needed
        # create_balance_sheet(tenant_id)
        # stats['balance_sheet_created'] = True
        
        # Uncomment if needed
        # from apps.xero.xero_integration.services import export_accounts
        # export_accounts(tenant_id)
        # stats['accounts_exported'] = True
        
        duration = time.time() - start_time
        stats['duration_seconds'] = duration
        
        return {
            'success': True,
            'message': f"Data processed for tenant {tenant_id}",
            'stats': stats
        }
        
    except Exception as e:
        duration = time.time() - start_time
        error_msg = f"Failed to process data for tenant {tenant_id}: {str(e)}"
        logger.error(error_msg)
        raise Exception(error_msg)
