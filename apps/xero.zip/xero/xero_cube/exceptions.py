"""
Custom exceptions for xero_cube app.
"""


class XeroCubeException(Exception):
    """Base exception for xero_cube app."""
    pass

# Add custom exceptions here

