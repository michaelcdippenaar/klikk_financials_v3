from django.apps import AppConfig


class XeroCubeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.xero.xero_cube'
    verbose_name = 'Xero Cube'

