"""
Constants for xero_cube app.
"""

# Constants will be added here

