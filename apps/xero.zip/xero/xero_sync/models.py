from django.db import models
from django.utils import timezone
import datetime
from apps.xero.xero_core.models import XeroTenant
import pytz


class XeroLastUpdateModelManager(models.Manager):
    def update_or_create_timestamp(self, end_point, organisation):
        utc_now = datetime.datetime.now(tz=pytz.utc)
        print(utc_now)
        self.update_or_create(end_point=end_point, organisation=organisation, defaults={'date': utc_now})

    def get_utc_date_time(self, end_point, organisation):
        instance, created = self.get_or_create(end_point=end_point, organisation=organisation, defaults={'date': None})
        if created or instance.date is None:
            return '1901-01-01T00:00:00'  # Default for new or None dates
        print(instance.date, 'line 76')
        return instance.date.isoformat(timespec='seconds')


class XeroLastUpdate(models.Model):
    end_point = models.CharField(max_length=100)
    date = models.DateTimeField(blank=True, null=True)
    organisation = models.ForeignKey(XeroTenant, on_delete=models.CASCADE, related_name='last_updates')

    objects = XeroLastUpdateModelManager()

    class Meta:
        unique_together = [('organisation', 'end_point')]

    def __str__(self):
        return f"{self.organisation.tenant_name}: {self.end_point} last updated at {self.date}"


class XeroTenantSchedule(models.Model):
    """Configuration for scheduled tasks per tenant."""
    tenant = models.OneToOneField(XeroTenant, on_delete=models.CASCADE, related_name='schedule')
    enabled = models.BooleanField(default=True, help_text="Enable/disable scheduled tasks for this tenant")
    update_interval_minutes = models.IntegerField(default=60, help_text="Minutes between update runs")
    update_start_time = models.TimeField(default=datetime.time(0, 0), help_text="Preferred start time for updates")
    last_update_run = models.DateTimeField(null=True, blank=True, help_text="Last time update task ran")
    last_process_run = models.DateTimeField(null=True, blank=True, help_text="Last time process task ran")
    next_update_run = models.DateTimeField(null=True, blank=True, help_text="Next scheduled update run")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['tenant__tenant_name']

    def __str__(self):
        return f"Schedule for {self.tenant.tenant_name}"

    def should_run_update(self):
        """Check if update task should run now."""
        if not self.enabled:
            return False
        if not self.next_update_run:
            return True
        return timezone.now() >= self.next_update_run

    def should_run_process(self):
        """
        Check if process task should run now (only after update completes).
        Process runs immediately after update, so check if update just completed.
        """
        if not self.enabled:
            return False
        if not self.last_update_run:
            return False  # Don't run process until update has run at least once
        
        # Process should run if update just completed and process hasn't run yet, or
        # if process hasn't run since the last update
        if not self.last_process_run:
            return True  # Process hasn't run yet after update
        
        # Process should run if it hasn't run since the last update
        return self.last_process_run < self.last_update_run

    def update_next_run_times(self):
        """Update next run times based on intervals (in minutes)."""
        now = timezone.now()
        if self.last_update_run:
            # Calculate next update time based on interval
            self.next_update_run = self.last_update_run + datetime.timedelta(minutes=self.update_interval_minutes)
        else:
            # First run - schedule for today at preferred time, or tomorrow if time has passed
            preferred_time = now.replace(
                hour=self.update_start_time.hour,
                minute=self.update_start_time.minute,
                second=0,
                microsecond=0
            )
            
            # If preferred time is in the past today, schedule for tomorrow
            if preferred_time <= now:
                self.next_update_run = preferred_time + datetime.timedelta(days=1)
            else:
                self.next_update_run = preferred_time
        
        # Process doesn't have a separate schedule - it runs immediately after update
        # So we don't set next_process_run anymore
        self.save()


class XeroTaskExecutionLog(models.Model):
    """Log execution stats for scheduled tasks."""
    TASK_TYPES = [
        ('update_models', 'Update Models'),
        ('process_data', 'Process Data'),
    ]
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('running', 'Running'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('skipped', 'Skipped'),
    ]

    tenant = models.ForeignKey(XeroTenant, on_delete=models.CASCADE, related_name='task_logs')
    task_type = models.CharField(max_length=20, choices=TASK_TYPES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    duration_seconds = models.FloatField(null=True, blank=True, help_text="Task duration in seconds")
    records_processed = models.IntegerField(null=True, blank=True, help_text="Number of records processed")
    error_message = models.TextField(null=True, blank=True)
    stats = models.JSONField(default=dict, blank=True, help_text="Additional statistics (e.g., API calls, DB queries)")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-started_at']
        indexes = [
            models.Index(fields=['tenant', 'task_type', 'status'], name='task_log_tenant_type_idx'),
            models.Index(fields=['tenant', 'started_at'], name='task_log_tenant_date_idx'),
            models.Index(fields=['status', 'started_at'], name='task_log_status_date_idx'),
        ]

    def __str__(self):
        return f"{self.tenant.tenant_name} - {self.get_task_type_display()} - {self.status}"

    def mark_completed(self, duration_seconds=None, records_processed=None, stats=None):
        """Mark task as completed with stats."""
        self.status = 'completed'
        self.completed_at = timezone.now()
        if duration_seconds is not None:
            self.duration_seconds = duration_seconds
        elif self.started_at:
            self.duration_seconds = (self.completed_at - self.started_at).total_seconds()
        if records_processed is not None:
            self.records_processed = records_processed
        if stats:
            self.stats = stats
        self.save()

    def mark_failed(self, error_message, duration_seconds=None):
        """Mark task as failed with error message."""
        self.status = 'failed'
        self.completed_at = timezone.now()
        self.error_message = error_message
        if duration_seconds is not None:
            self.duration_seconds = duration_seconds
        elif self.started_at:
            self.duration_seconds = (self.completed_at - self.started_at).total_seconds()
        self.save()
