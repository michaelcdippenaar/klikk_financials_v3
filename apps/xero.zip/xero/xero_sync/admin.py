from django.contrib import admin
from apps.xero.xero_sync.models import XeroLastUpdate, XeroTenantSchedule, XeroTaskExecutionLog


@admin.register(XeroLastUpdate)
class XeroLastUpdateAdmin(admin.ModelAdmin):
    list_display = ('organisation', 'end_point', 'date')
    list_filter = ('end_point', 'date')
    search_fields = ('organisation__tenant_name', 'end_point')
    readonly_fields = ('organisation', 'end_point', 'date')


@admin.register(XeroTenantSchedule)
class XeroTenantScheduleAdmin(admin.ModelAdmin):
    list_display = ('tenant', 'enabled', 'update_interval_minutes', 'last_update_run', 'next_update_run')
    list_filter = ('enabled', 'update_interval_minutes')
    search_fields = ('tenant__tenant_name', 'tenant__tenant_id')
    readonly_fields = ('created_at', 'updated_at')


@admin.register(XeroTaskExecutionLog)
class XeroTaskExecutionLogAdmin(admin.ModelAdmin):
    list_display = ('tenant', 'task_type', 'status', 'started_at', 'completed_at', 'duration_seconds', 'records_processed')
    list_filter = ('task_type', 'status', 'started_at')
    search_fields = ('tenant__tenant_name', 'tenant__tenant_id', 'error_message')
    readonly_fields = ('started_at', 'completed_at', 'created_at')
    date_hierarchy = 'started_at'
