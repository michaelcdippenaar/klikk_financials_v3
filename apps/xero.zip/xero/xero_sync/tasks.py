"""
Scheduled tasks for Xero data synchronization.
Uses APScheduler to run tasks hourly per tenant.
"""
import logging
import time
from django.utils import timezone
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger

from apps.xero.xero_core.models import XeroTenant
from apps.xero.xero_sync.models import XeroTenantSchedule, XeroTaskExecutionLog
from apps.xero.xero_sync.services import update_xero_models
from apps.xero.xero_cube.services import process_xero_data

logger = logging.getLogger(__name__)

# Global scheduler instance
scheduler = None


def run_update_task(tenant_id):
    """
    Run update models task for a specific tenant.
    This is called by the scheduler.
    """
    log_entry = None
    try:
        tenant = XeroTenant.objects.get(tenant_id=tenant_id)
        schedule = XeroTenantSchedule.objects.get(tenant=tenant)
        
        # Check if task should run
        if not schedule.should_run_update():
            logger.info(f"Skipping update task for tenant {tenant_id} - not scheduled yet")
            return
        
        # Create log entry
        log_entry = XeroTaskExecutionLog.objects.create(
            tenant=tenant,
            task_type='update_models',
            status='running'
        )
        
        logger.info(f"Starting update task for tenant {tenant_id}")
        start_time = time.time()
        
        # Run the update
        result = update_xero_models(tenant_id)
        
        duration = time.time() - start_time
        
        # Update schedule
        schedule.last_update_run = timezone.now()
        schedule.update_next_run_times()
        
        # Mark log as completed with API call count
        records_processed = sum([
            result['stats'].get('accounts_updated', 0),
            result['stats'].get('contacts_updated', 0),
            result['stats'].get('tracking_categories_updated', 0),
            result['stats'].get('bank_transactions_updated', 0),
            result['stats'].get('invoices_updated', 0),
            result['stats'].get('payments_updated', 0),
            result['stats'].get('journals_updated', 0),
        ])
        
        # Log API calls
        api_calls = result['stats'].get('api_calls', 0)
        logger.info(f"Update task for tenant {tenant_id} made {api_calls} API calls")
        
        log_entry.mark_completed(
            duration_seconds=duration,
            records_processed=records_processed,
            stats=result.get('stats', {})
        )
        
        logger.info(f"Completed update task for tenant {tenant_id} in {duration:.2f} seconds")
        
        # Immediately trigger process task after update completes (only if update was successful)
        if result.get('success', False):
            logger.info(f"Triggering process task for tenant {tenant_id} after update completion")
            try:
                run_process_task(tenant_id)
            except Exception as e:
                logger.error(f"Error running process task after update for {tenant_id}: {str(e)}", exc_info=True)
        else:
            logger.warning(f"Skipping process task for tenant {tenant_id} due to update errors")
        
    except XeroTenant.DoesNotExist:
        error_msg = f"Tenant {tenant_id} not found"
        logger.error(error_msg)
        if log_entry:
            log_entry.mark_failed(error_msg)
    except XeroTenantSchedule.DoesNotExist:
        error_msg = f"Schedule not configured for tenant {tenant_id}"
        logger.warning(error_msg)
        if log_entry:
            log_entry.status = 'skipped'
            log_entry.error_message = error_msg
            log_entry.completed_at = timezone.now()
            log_entry.save()
    except ValueError as e:
        # Handle authentication/token errors specifically
        error_msg = f"Update task failed for tenant {tenant_id}: {str(e)}"
        logger.error(error_msg, exc_info=True)
        if log_entry:
            log_entry.mark_failed(error_msg)
        # Don't trigger process task if update failed due to authentication
        logger.warning(f"Skipping process task for tenant {tenant_id} due to update failure")
    except Exception as e:
        error_msg = f"Update task failed for tenant {tenant_id}: {str(e)}"
        logger.error(error_msg, exc_info=True)
        if log_entry:
            log_entry.mark_failed(error_msg)
        # Don't trigger process task if update failed
        logger.warning(f"Skipping process task for tenant {tenant_id} due to update failure")


def run_process_task(tenant_id):
    """
    Run process data task for a specific tenant.
    This runs after update task completes.
    """
    log_entry = None
    try:
        tenant = XeroTenant.objects.get(tenant_id=tenant_id)
        schedule = XeroTenantSchedule.objects.get(tenant=tenant)
        
        # Check if task should run (only after update has run)
        if not schedule.should_run_process():
            logger.info(f"Skipping process task for tenant {tenant_id} - update not completed yet")
            return
        
        # Create log entry
        log_entry = XeroTaskExecutionLog.objects.create(
            tenant=tenant,
            task_type='process_data',
            status='running'
        )
        
        logger.info(f"Starting process task for tenant {tenant_id}")
        start_time = time.time()
        
        # Run the process
        result = process_xero_data(tenant_id)
        
        duration = time.time() - start_time
        
        # Update schedule - process doesn't have separate schedule, just track when it ran
        schedule.last_process_run = timezone.now()
        schedule.save()  # Don't call update_next_run_times for process - it's tied to update
        
        # Mark log as completed
        records_processed = 0  # Trail balance doesn't return record count easily
        log_entry.mark_completed(
            duration_seconds=duration,
            records_processed=records_processed,
            stats=result.get('stats', {})
        )
        
        logger.info(f"Completed process task for tenant {tenant_id} in {duration:.2f} seconds")
        
    except XeroTenant.DoesNotExist:
        error_msg = f"Tenant {tenant_id} not found"
        logger.error(error_msg)
        if log_entry:
            log_entry.mark_failed(error_msg)
    except XeroTenantSchedule.DoesNotExist:
        error_msg = f"Schedule not configured for tenant {tenant_id}"
        logger.warning(error_msg)
        if log_entry:
            log_entry.status = 'skipped'
            log_entry.error_message = error_msg
            log_entry.completed_at = timezone.now()
            log_entry.save()
    except Exception as e:
        error_msg = f"Process task failed for tenant {tenant_id}: {str(e)}"
        logger.error(error_msg, exc_info=True)
        if log_entry:
            log_entry.mark_failed(error_msg)


def check_and_run_scheduled_tasks():
    """
    Check all tenant schedules and run tasks that are due.
    This function runs every minute to check for due tasks.
    """
    try:
        schedules = XeroTenantSchedule.objects.filter(enabled=True)
        
        for schedule in schedules:
            tenant_id = schedule.tenant.tenant_id
            
            # Check and run update task if due
            # Process task will be triggered automatically after update completes
            if schedule.should_run_update():
                try:
                    run_update_task(tenant_id)
                    # Note: run_update_task now automatically triggers run_process_task
                except Exception as e:
                    logger.error(f"Error running update task for {tenant_id}: {str(e)}", exc_info=True)
                    
    except Exception as e:
        logger.error(f"Error in scheduled task checker: {str(e)}", exc_info=True)


def start_scheduler():
    """Start the APScheduler background scheduler."""
    global scheduler
    
    if scheduler and scheduler.running:
        logger.warning("Scheduler is already running")
        return
    
    scheduler = BackgroundScheduler()
    
    # Schedule the checker to run every minute
    scheduler.add_job(
        check_and_run_scheduled_tasks,
        trigger=IntervalTrigger(minutes=1),
        id='xero_scheduled_tasks_checker',
        name='Check and run Xero scheduled tasks',
        replace_existing=True,
    )
    
    scheduler.start()
    logger.info("Xero task scheduler started - checking for due tasks every minute")


def stop_scheduler():
    """Stop the APScheduler background scheduler."""
    global scheduler
    
    if scheduler and scheduler.running:
        scheduler.shutdown()
        logger.info("Xero task scheduler stopped")
    else:
        logger.warning("Scheduler is not running")

