"""
Custom exceptions for xero_auth app.
"""


class XeroAuthException(Exception):
    """Base exception for xero_auth app."""
    pass

# Add custom exceptions here

