"""
Utility functions for xero_auth app.
"""

# Utility functions will be added here

