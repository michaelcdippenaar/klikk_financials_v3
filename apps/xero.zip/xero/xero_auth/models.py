from django.db import models
from django.conf import settings
from apps.xero.xero_core.models import XeroTenant


class XeroClientCredentials(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='xero_client_credentials', on_delete=models.CASCADE)
    client_id = models.CharField(max_length=100)
    client_secret = models.CharField(max_length=100)
    scope = models.JSONField(blank=True)
    token = models.JSONField(blank=True, null=True)  # Store OAuth2 token
    refresh_token = models.CharField(max_length=1000, blank=True, null=True)
    expires_at = models.DateTimeField(blank=True, null=True)
    active = models.BooleanField(default=True)

    def __str__(self):
        return f"Credentials for {self.user}"


class XeroTenantToken(models.Model):
    tenant = models.ForeignKey(XeroTenant, on_delete=models.CASCADE, related_name='tenant_tokens')
    credentials = models.ForeignKey('XeroClientCredentials', on_delete=models.CASCADE, related_name='tenant_tokens')
    token = models.JSONField()  # Tenant-specific token
    refresh_token = models.CharField(max_length=1000)
    expires_at = models.DateTimeField()
    connected_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [('tenant', 'credentials')]

    def __str__(self):
        return f"Token for {self.tenant.tenant_name}"


class XeroAuthSettings(models.Model):
    access_token_url = models.CharField(max_length=255)
    refresh_url = models.CharField(max_length=255)
    auth_url = models.CharField(max_length=255)
