"""
Constants for xero_auth app.
"""

# Constants will be added here

