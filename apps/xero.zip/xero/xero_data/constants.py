"""
Constants for xero_data app.
"""

# Constants will be added here

