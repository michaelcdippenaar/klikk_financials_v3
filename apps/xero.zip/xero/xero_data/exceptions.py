"""
Custom exceptions for xero_data app.
"""


class XeroDataException(Exception):
    """Base exception for xero_data app."""
    pass

# Add custom exceptions here

