from django.db import models

# Custom managers will be added here

