from rest_framework import permissions

# Custom permissions will be added here

