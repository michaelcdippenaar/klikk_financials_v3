"""
Xero data views - transaction and journal data update endpoints.
"""
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny

from apps.xero.xero_core.models import XeroTenant
from apps.xero.xero_auth.models import XeroClientCredentials
from apps.xero.xero_data.services import update_xero_data
from apps.xero.xero_data.models import XeroJournalsSource


class XeroUpdateDataView(APIView):
    """
    API endpoint to update Xero transaction data (bank_transactions, invoices, payments, journals).
    This is separate from metadata updates (accounts, contacts, tracking categories).
    """
    permission_classes = [AllowAny]  # TODO: Change to IsAuthenticated for production

    def post(self, request):
        """
        Update transaction data for a specific tenant.
        
        Expected payload:
        {
            "tenant_id": "string",
            "load_all": true,  // Optional, default: true - If true, ignores last update timestamp and loads everything.
                              // If false, uses incremental updates based on last update timestamp.
                              // Note: This controls timestamp behavior, not which journal types to load.
            "load_manual_journals": true,  // Optional, default: true - load manual journals
            "load_journals": true  // Optional, default: true - load regular journals
        }
        """
        tenant_id = request.data.get('tenant_id')
        if not tenant_id:
            return Response({"error": "tenant_id is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        # Get journal loading parameters (defaults to True for all)
        load_all = request.data.get('load_all', True)
        load_manual_journals = request.data.get('load_manual_journals', True)
        load_journals = request.data.get('load_journals', True)

        try:
            tenant = XeroTenant.objects.get(tenant_id=tenant_id)
        except XeroTenant.DoesNotExist:
            return Response({"error": "Tenant not found"}, status=status.HTTP_404_NOT_FOUND)

        try:
            # TODO: When adding authentication back, use request.user
            # For now, get user from first active credentials (development only)
            if request.user.is_authenticated:
                user = request.user
            else:
                credentials = XeroClientCredentials.objects.filter(active=True).first()
                if not credentials:
                    return Response({"error": "No active Xero credentials found"}, status=status.HTTP_403_FORBIDDEN)
                user = credentials.user
            
            # Use the service function for consistency with scheduled tasks
            result = update_xero_data(
                tenant_id, 
                user=user,
                load_all=load_all,
                load_manual_journals=load_manual_journals,
                load_journals=load_journals
            )
            
            if result['success']:
                return Response({
                    "message": result['message'],
                    "stats": result['stats']
                }, status=status.HTTP_200_OK)
            else:
                return Response({
                    "message": result['message'],
                    "errors": result['errors'],
                    "stats": result['stats']
                }, status=status.HTTP_207_MULTI_STATUS)
        except ValueError as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except Exception as e:
            return Response({"error": f"Failed to update data: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class XeroProcessJournalsView(APIView):
    """
    API endpoint to process journals from XeroJournalsSource to XeroJournals.
    This parses the raw journal data and creates individual journal line records.
    Handles both regular journals and manual journals.
    """
    permission_classes = [AllowAny]  # TODO: Change to IsAuthenticated for production

    def post(self, request):
        """
        Process journals from XeroJournalsSource to XeroJournals.
        
        Expected payload:
        {
            "tenant_id": "string"
        }
        """
        tenant_id = request.data.get('tenant_id')
        if not tenant_id:
            return Response({"error": "tenant_id is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            tenant = XeroTenant.objects.get(tenant_id=tenant_id)
        except XeroTenant.DoesNotExist:
            return Response({"error": "Tenant not found"}, status=status.HTTP_404_NOT_FOUND)

        try:
            # Count unprocessed journals before processing
            unprocessed_count = XeroJournalsSource.objects.filter(
                organisation=tenant,
                processed=False
            ).count()
            
            if unprocessed_count == 0:
                return Response({
                    "message": f"No unprocessed journals found for tenant {tenant_id}",
                    "journals_processed": 0
                }, status=status.HTTP_200_OK)
            
            # Process journals from XeroJournalsSource to XeroJournals
            result = XeroJournalsSource.objects.create_journals_from_xero(tenant)
            
            # Count processed journals
            processed_count = result.count()
            
            return Response({
                "message": f"Successfully processed {processed_count} journal lines for tenant {tenant_id}",
                "journals_processed": processed_count,
                "unprocessed_before": unprocessed_count
            }, status=status.HTTP_200_OK)
            
        except Exception as e:
            return Response({
                "error": f"Failed to process journals: {str(e)}"
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
