# from django.apps import AppConfig


# class XeroValidationConfig(AppConfig):
#     default_auto_field = 'django.db.models.BigAutoField'
#     name = 'apps.xero.xero_validation'
#     verbose_name = 'Xero Validation'
    
#     def ready(self):
#         import apps.xero.xero_validation.signals  # noqa

