from django.urls import path

app_name = 'xero_integration'

urlpatterns = [
    # URL patterns will be added here
]

